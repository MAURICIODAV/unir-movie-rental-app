function Footer() {
  return (
    <footer className="footer">
      <p>&copy; {new Date().getFullYear()} Plataforma de Streaming UNIR - Mauricio Correa</p>
    </footer>
  );
}

export default Footer;