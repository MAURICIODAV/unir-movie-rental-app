// microservicio-contenido/src/routes/content.js
import express from 'express';
import Content from '../models/content.js';

const router = express.Router();

// GET /api/content/:type
router.get('/:type', async (req, res) => {
  try {
    const content = await Content.find({ 
      type: req.params.type,
      ...req.query 
    });
    res.json(content);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST /api/content/:type
router.post('/:type', async (req, res) => {
  try {
    const content = new Content({
      type: req.params.type,
      ...req.body
    });
    await content.save();
    res.status(201).json(content);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

export default router;