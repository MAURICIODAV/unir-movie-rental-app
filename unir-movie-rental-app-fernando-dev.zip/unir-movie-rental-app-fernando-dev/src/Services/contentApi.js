// frontend/src/services/contentApi.js
const API_BASE_URL = process.env.REACT_APP_CONTENT_API_URL || 'http://localhost:5173/api';

export const contentApi = {
  // Operaciones CRUD
  getContent: async (contentType, filters = {}) => {
    const response = await fetch(`${API_BASE_URL}/content/${contentType}?${new URLSearchParams(filters)}`);
    return response.json();
  },

  createContent: async (contentType, data) => {
    const response = await fetch(`${API_BASE_URL}/content/${contentType}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });
    return response.json();
  },

  updateContent: async (contentType, id, data) => {
    const response = await fetch(`${API_BASE_URL}/content/${contentType}/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });
    return response.json();
  },

  deleteContent: async (contentType, id) => {
    const response = await fetch(`${API_BASE_URL}/content/${contentType}/${id}`, {
      method: 'DELETE',
    });
    return response.json();
  }
};